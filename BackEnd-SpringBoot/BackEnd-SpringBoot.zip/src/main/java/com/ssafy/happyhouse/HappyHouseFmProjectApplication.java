package com.ssafy.happyhouse;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@MapperScan({"com.ssafy.happyhouse.model.mapper"})
@SpringBootApplication
public class HappyHouseFmProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(HappyHouseFmProjectApplication.class, args);
	}

}
