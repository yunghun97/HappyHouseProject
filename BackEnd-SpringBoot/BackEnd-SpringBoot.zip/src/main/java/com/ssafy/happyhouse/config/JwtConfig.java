package com.ssafy.happyhouse.config;

public class JwtConfig {

}
