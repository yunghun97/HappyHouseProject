package com.ssafy.happyhouse.model;
public class GuguncodeDto {

    private String gugunCode;
    private String gugunName;
    
	public String getGugunCode() {
		return gugunCode;
	}
	public void setGugunCode(String gugunCode) {
		this.gugunCode = gugunCode;
	}
	public String getGugunName() {
		return gugunName;
	}
	public void setGugunName(String gugunName) {
		this.gugunName = gugunName;
	}
    
}